# country-capitals

This is a sample CouchDB / Kanso application. 

Read more about it here:

* [http://icyrock.com/blog/2011/08/couchdb-and-kanso/](http://icyrock.com/blog/2011/08/couchdb-and-kanso/)
